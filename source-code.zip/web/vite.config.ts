import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
export default defineConfig({build:{assetsDir:process.env.PAGES_FLAT==='1'?'':'assets'},base:process.env.PAGES_BASE || './',plugins:[react(),VitePWA({
  registerType:'prompt', includeAssets:['icon.svg','icon-180.png'], manifest:{name:'Практика · 1С:Специалист',short_name:'Практика 1С',lang:'ru',start_url:'./',scope:'./',display:'standalone',background_color:'#f6f5f0',theme_color:'#ffd348',icons:[{src:'icon-192.png',sizes:'192x192',type:'image/png',purpose:'any'},{src:'icon-512.png',sizes:'512x512',type:'image/png',purpose:'any maskable'}]},
  workbox:{globPatterns:['**/*.{js,css,html,svg,png,woff2}'],navigateFallback:'index.html',cleanupOutdatedCaches:true}
})]});
