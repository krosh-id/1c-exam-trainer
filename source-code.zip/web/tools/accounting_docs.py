"""Read accounting reference tables without changing the Word sources."""
import hashlib,json,re,zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
W='{'+NS['w']+'}'
FILES={**{(n,False):f'{n}.docx' for n in range(1,17) if n!=6},(1,True):'доп 1 кролики.docx',(2,True):'доп 2 возврат.docx',(3,True):'доп 3.docx'}

def read_tables(path):
    raw=path.read_bytes()
    with zipfile.ZipFile(path) as z:document=ET.fromstring(z.read('word/document.xml'))
    tables=[]
    for table in document.findall('.//w:tbl',NS):
        rows=[];active={}
        for row in table.findall('w:tr',NS):
            cells=[];column=0;next_active={};continued=set()
            before=row.find('w:trPr/w:gridBefore',NS)
            if before is not None:
                column=int(before.get(W+'val','0'))
                if column:cells.append(dict(column=0,text='',rowSpan=1,colSpan=column,omitted=True))
            for cell in row.findall('w:tc',NS):
                span=cell.find('w:tcPr/w:gridSpan',NS);width=int(span.get(W+'val','1')) if span is not None else 1
                merge=cell.find('w:tcPr/w:vMerge',NS)
                paragraphs=[]
                for p in cell.findall('w:p',NS):paragraphs.append(''.join((node.text or '') if node.tag==W+'t' else '\n' if node.tag==W+'br' else '\t' if node.tag==W+'tab' else '' for node in p.iter()))
                text='\n'.join(paragraphs)
                if merge is not None and merge.get(W+'val')!='restart':
                    origin=active.get(column)
                    if origin is None or origin['colSpan']!=width or text.strip():raise ValueError(f'{path.name}: unsupported vertical continuation at column {column}')
                    if id(origin) not in continued:origin['rowSpan']+=1;continued.add(id(origin))
                    for c in range(column,column+width):next_active[c]=origin
                else:
                    origin=dict(column=column,text=text,rowSpan=1,colSpan=width);cells.append(origin)
                    if merge is not None:
                        for c in range(column,column+width):next_active[c]=origin
                column+=width
            after=row.find('w:trPr/w:gridAfter',NS)
            if after is not None:
                width=int(after.get(W+'val','0'))
                if width:cells.append(dict(column=column,text='',rowSpan=1,colSpan=width,omitted=True));column+=width
            if column!=5:raise ValueError(f'{path.name}: expected five columns, found {column}')
            rows.append(cells);active=next_active
        tables.append(rows)
    if not tables:raise ValueError(f'{path.name}: no tables')
    return dict(source=path.name,version=hashlib.sha256(raw).hexdigest(),tables=tables)

def attach_references(tickets,folder):
    folder=Path(folder);references={key:read_tables(folder/name) for key,name in FILES.items() if (folder/name).is_file()}
    for t in tickets:
        if t['section']!='БУ':continue
        reference=references.get((t['number'],t['additional']))
        if reference:
            base=t.get('accounting_base_version',t['version']);t['accounting_base_version']=base;t['accountingReference']=reference
            t['version']=hashlib.sha256((base+'\naccounting-docx-v1\n'+reference['version']).encode('utf-8')).hexdigest();t['source']['version']=t['version']
    return len(references)

def update_package(package,folder):
    with zipfile.ZipFile(package) as z:files={name:z.read(name) for name in z.namelist() if name!='manifest.json'}
    data=json.loads(files['materials.json']);count=attach_references(data['tickets'],folder)
    versions=[(t['id'],t['version']) for t in data['tickets']]
    data['id']=hashlib.sha256(json.dumps([versions,data.get('library',[]),data['frequency'],data['seed']],ensure_ascii=False,sort_keys=True).encode('utf-8')).hexdigest()
    from datetime import datetime,timezone
    data['createdAt']=datetime.now(timezone.utc).isoformat()
    files['materials.json']=json.dumps(data,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    manifest={'format':1,'files':{name:hashlib.sha256(content).hexdigest() for name,content in files.items()}}
    output=package.with_suffix('.updated.zip')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for name,content in files.items():z.writestr(name,content)
        z.writestr('manifest.json',json.dumps(manifest).encode('utf-8'))
    output.replace(package)
    return count

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--package',type=Path,required=True);parser.add_argument('--folder',type=Path,required=True);args=parser.parse_args()
    print(json.dumps({'references':update_package(args.package,args.folder)},ensure_ascii=False))
