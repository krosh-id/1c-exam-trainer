"""Create an allowlisted source archive for a new public GitHub repository."""
from pathlib import Path
import zipfile,json

def package():
    root=Path(__file__).resolve().parents[2];web=root/'web'
    names=['package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','.gitignore','README.md']
    paths=[web/name for name in names]
    paths.extend(p for folder in ('src','public','tools') for p in (web/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    paths.append(root/'.github/workflows/pages.yml')
    target=web/'private/github-pages-project.zip';target.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for path in sorted(paths):z.write(path,path.relative_to(root).as_posix())
    print(json.dumps({'archive':str(target),'files':len(paths),'bytes':target.stat().st_size},ensure_ascii=False))
if __name__=='__main__':package()
