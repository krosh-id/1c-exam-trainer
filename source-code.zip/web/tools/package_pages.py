"""Allowlisted flat build for publishing through GitHub's file picker."""
from pathlib import Path
import json,zipfile

def package():
    root=Path(__file__).resolve().parents[2];web=root/'web';dist=web/'dist'
    if any(p.is_dir() for p in dist.iterdir()):raise ValueError('Build with PAGES_FLAT=1 before preparing a browser upload.')
    target=web/'private/pages-accounting-release';target.mkdir(exist_ok=True)
    files=[]
    for path in dist.iterdir():
        if path.is_file() and path.suffix in ('.js','.css','.html','.svg','.png','.webmanifest'):
            dest=target/path.name;dest.write_bytes(path.read_bytes());files.append(dest)
    source=web/'private/github-pages-project.zip'
    with zipfile.ZipFile(source) as z:
        if any('/private/' in n or n.startswith('sources/') or n.endswith(('.sqlite','.docx','.xlsx')) for n in z.namelist()):raise ValueError('Private material in source archive')
    (target/'source-code.zip').write_bytes(source.read_bytes());files.append(target/'source-code.zip')
    (target/'.nojekyll').write_text('',encoding='utf-8');files.append(target/'.nojekyll')
    (target/'README.md').write_text('''# Практика 1С Специалист

Сайт: https://krosh-id.github.io/1c-exam-trainer/

Готовая статическая сборка приложения. [Исходники](source-code.zip) включают web/ и workflow для перехода на автоматическую сборку. Текущая публикация: Pages → Deploy from a branch → main → /(root).

## Схема учёта БУ

В режиме «Спроектируй решение» создавайте показатели, счета и строки субконто, измерений и итогов. На компьютере доступен ввод в таблицу с объединёнными ячейками; на телефоне — карточки и переключение в общий табличный вид. Схема сохраняется автоматически, старые попытки доступны без потери текста. Эталон Word появляется после завершения этапа.

Личные конспекты, заполненные Word-таблицы, изображения и прогресс не опубликованы. Для чтения эталонов загрузите обновлённый приватный materials.zip через «Материалы». Новые Word-таблицы подготовлены для 18 заданий БУ; для №6 отдельный файл не предоставлен. Старые пакеты продолжают работать без новых эталонов. История сохраняется, изменение эталона отмечается новой версией материалов.

## Обновление сайта

Исходный проект: npm ci, затем PAGES_BASE=/1c-exam-trainer/ PAGES_FLAT=1 npm run build (переменные задаются средствами вашей оболочки). Обновите файлы web/dist/ в корне репозитория. Сохраните новую версию source-code.zip. Материалы и резервные копии прогресса в репозиторий не добавляйте.
''',encoding='utf-8');files.append(target/'README.md')
    print(json.dumps({'files':[str(p) for p in sorted(files)]},ensure_ascii=False))

if __name__=='__main__':package()
