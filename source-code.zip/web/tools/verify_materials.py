"""Private integration checks; no changes to notes. Run after exporting."""
import sys,unittest,json,zipfile,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from trainer.parser import load_tickets
from trainer.ordering import exercises_for_ticket,grade_order,OrderExercise,Card
from trainer.exercises import normalize
from trainer.design_model import validate,definition,KINDS,TABLE_NAMES
from export_materials import excel_frequencies
ROOT=Path(__file__).resolve().parents[2]
class MaterialTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.vault=Path('D:/1c specialist codex/obsidian-vault-1c');cls.tickets,_=load_tickets(cls.vault)
        with zipfile.ZipFile(ROOT/'web/private/materials.zip') as z:
            cls.data=json.loads(z.read('materials.json'));manifest=json.loads(z.read('manifest.json'))
            for path,digest in manifest['files'].items():assert hashlib.sha256(z.read(path)).hexdigest()==digest
    def test_source_fidelity(self):
        self.assertEqual(len(self.data['tickets']),54)
        for t in self.tickets:
            exported=next(x for x in self.data['tickets'] if x['id']==t.id)
            self.assertEqual([f['code'] for f in exported['fragments']],[f.code for f in t.fragments])
            for e in exercises_for_ticket(t):
                self.assertTrue(all(grade_order(e,[c.id for c in e.cards])))
                if len(e.cards)>1:
                    ids=[c.id for c in e.cards];ids[0],ids[-1]=ids[-1],ids[0]
                    self.assertEqual(len(grade_order(e,ids)),len(ids))
            for item in exported['exercises']:
                e=OrderExercise(**{**item,'cards':tuple(Card(**c) for c in item['cards'])})
                self.assertTrue(all(grade_order(e,[c.id for c in e.cards])))
                source=''.join(c.source for c in e.cards)
                original=next(f.code for f in t.fragments if f.id==e.fragment_id)
                if e.kind=='module':self.assertEqual(source,original)
                else:self.assertIn(source,original)
    def test_schema_and_seeds(self):
        self.assertEqual(json.loads((ROOT/'web/src/schema.json').read_text(encoding='utf-8')),dict(kinds=list(KINDS),definitions={k:list(definition(k)) for k in KINDS},tableNames=TABLE_NAMES))
        for section,objects in self.data['seed']['objects'].items():self.assertEqual(validate(dict(objects=objects,formulas=[],variables=[],dependencies=[])),[])
    def test_sections(self):
        for t in self.data['tickets']:
            if t['section']=='БУ':self.assertNotIn('В заметке нет этого раздела',t['source']['sections']['Схема учёта'])
            if t['section']=='ОУ':self.assertNotIn('### Регистр накопления',t['source']['sections']['Прочие объекты'])
        spr=[t for t in self.data['tickets'] if t['section']=='СПР' and not t['additional']]
        self.assertTrue(next(t for t in spr if t['number']==7)['exercises'])
        self.assertFalse(next(t for t in spr if t['number']==9)['exercises'])
    def test_excel(self):
        old=json.loads((ROOT/'trainer/data/frequencies.json').read_text(encoding='utf-8'))
        self.assertEqual(self.data['frequency']['records'],345)
        self.assertEqual(self.data['frequency']['counts'],old['counts'])
    def test_sources_untouched(self):
        audit=ROOT/'web/private/accounting-sources-before.json'
        before=json.loads((audit if audit.exists() else ROOT/'web/private/sources-before.json').read_text(encoding='utf-8'))
        for path,digest in before.items():self.assertEqual(hashlib.sha256(Path(path).read_bytes()).hexdigest(),digest,path)
        actual={str(p) for p in self.vault.rglob('*') if p.is_file()}
        self.assertEqual(actual,{p for p in before if Path(p).is_relative_to(self.vault)})
if __name__=='__main__':unittest.main()
