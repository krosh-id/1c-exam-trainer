import sys,unittest,tempfile,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from note_library import build_library

class LibraryTests(unittest.TestCase):
    def test_links_and_literals(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'web/private') as folder:
            root=Path(folder);(root/'Теория').mkdir()
            text='# Тема\n[[Другая#Раздел|Читать]]\n```\n[[Скрытая]]\n![[скрыто.png]]\n```\n`[[Литерал]]`\n![[нет.png]]'
            (root/'Теория/Тема.md').write_text(text,encoding='utf-8');(root/'Другая.md').write_text('# Другая',encoding='utf-8')
            notes=build_library(root,lambda *_:self.fail('No images expected'))
            note=next(n for n in notes if n['title']=='Тема')
            self.assertEqual(note['content'],text)
            self.assertEqual(note['links'],{'Другая#Раздел':{'id':'Другая.md','heading':'Раздел'}})
            self.assertEqual(list(note['images']),['нет.png'])

    @unittest.skipUnless((ROOT/'web/private/theory-before.json').exists(),'Local source audit')
    def test_real_library_fidelity_and_source_integrity(self):
        before=json.loads((ROOT/'web/private/theory-before.json').read_text(encoding='utf-8'))
        vault=Path(r'D:\1c specialist codex\obsidian-vault-1c')
        with zipfile.ZipFile(ROOT/'web/private/materials.zip') as z:data=json.loads(z.read('materials.json'))
        self.assertEqual(len(data['library']),len(list(vault.rglob('*.md'))))
        for note in data['library']:self.assertEqual(note['content'],(vault/note['path']).read_text(encoding='utf-8-sig'))
        for t in data['tickets']:self.assertEqual(t['version'],before['ticket_versions'][t['id']])
        for name,digest in before['hashes'].items():self.assertEqual(hashlib.sha256(Path(name).read_bytes()).hexdigest(),digest,name)
        current={str(p) for p in vault.rglob('*') if p.is_file()}
        original={name for name in before['hashes'] if Path(name).is_relative_to(vault)}
        self.assertEqual(current,original)

if __name__=='__main__':unittest.main()

