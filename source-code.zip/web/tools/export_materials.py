"""Read-only preparation of a private offline package. Run from the project root."""
import argparse, base64, hashlib, json, mimetypes, re, sys, zipfile
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from trainer.parser import load_tickets,resolve_attachment
from trainer.ordering import exercises_for_ticket
from trainer.design_sources import capture_source,section
from trainer.design_model import KINDS,definition,TABLE_NAMES
from note_library import build_library

def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return json.dumps(value,ensure_ascii=False,separators=(',',':')).encode('utf-8')

def excel_frequencies(path):
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(path) as z:
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
        book=ET.fromstring(z.read('xl/workbook.xml'))
        sheet=next(e for e in book.findall('m:sheets/m:sheet',ns) if e.attrib['name']=='Спец Пл')
        rid=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target=next(e.attrib['Target'] for e in rels if e.attrib['Id']==rid)
        sheetpath=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        counts=Counter();dates=[]
        for row in ET.fromstring(z.read(sheetpath)).findall('m:sheetData/m:row',ns):
            values={}
            for cell in row:
                v=cell.find('m:v',ns);value=v.text if v is not None else ''
                if cell.attrib.get('t')=='s':value=strings[int(value)]
                elif cell.attrib.get('t')=='inlineStr':value=''.join(cell.find('m:is',ns).itertext())
                values[re.sub(r'\d','',cell.attrib['r'])]=value
            raw=values.get('A','')
            try:date=(datetime(1899,12,30)+timedelta(days=float(raw))) if re.fullmatch(r'[\d.]+',raw) else datetime.fromisoformat(raw)
            except (ValueError,TypeError):continue
            if date.year!=2026:continue
            dates.append(date.date().isoformat())
            for section,column in [('ОУ','E'),('БУ','G'),('СПР','I')]:
                value=values.get(column,'').strip().lower().replace(' ','')
                match=re.fullmatch(r'(доп)?(\d+)(?:\.0)?',value)
                if match:counts[f'{section}:{"доп" if match[1] else ""}{int(match[2])}']+=1
                elif value:raise ValueError(f'Неоднозначный номер {section}: {value}, строка {row.attrib.get("r")}')
    return dict(source=path.name,source_sheet='Спец Пл',source_sha256=sha(path.read_bytes()),period_start='2026-01-01',period_end=max(dates) if dates else '2026-01-01',records=len(dates),counts=dict(counts))

def export(vault,excel,docx,output):
    tickets,issues=load_tickets(vault)
    if issues:raise ValueError('\n'.join(issues))
    frequency=excel_frequencies(excel)
    seed=json.loads((ROOT/'trainer/data/design-seed.json').read_text(encoding='utf-8'))
    # The existing transcription is tied to this document; never silently use a changed DOCX.
    prior=seed.get('docx_sha256')
    if prior and prior!=sha(docx.read_bytes()):raise ValueError('DOCX изменился: сначала обновите транскрипцию стартового каркаса.')
    files={};assets={};result=[];audit=[]
    mappings=json.loads(Path(__file__).with_name('source_sections.json').read_text(encoding='utf-8'))
    def asset(data,suffix):
        name='assets/'+sha(data)+suffix.lower();files[name]=data
        assets[name]={'type':mimetypes.guess_type(name)[0] or 'application/octet-stream'}
        return name
    for ticket in tickets:
        literal_assignment=re.compile(r'^([ \t]*[\wА-Яа-яЁё.]+\s*=\s*)("\s*(?:ВЫБРАТЬ|ВЫБРАТЬ\s+РАЗРЕШЕННЫЕ)\b)',re.I|re.M)
        item=asdict(ticket);item['exercises']=[asdict(e) for e in exercises_for_ticket(ticket,assignment_pattern=literal_assignment)]
        # «Доп затраты» is the subject of main БУ №2, not the ДОП marker before №.
        item['additional']=bool(re.match(r'^(?:ОУ|БУ|СПР)\s+ДОП\s*№',ticket.title,re.I))
        source=capture_source(ticket,vault)
        text=(vault/ticket.path).read_text(encoding='utf-8-sig')
        source['sections']['Схема учёта']=next((section(text,h) for h in mappings['accountingHeadings'] if re.search('^'+re.escape(h)+r'\s*$',text,re.M)),'В заметке нет этого раздела; эталон не добавлялся.')
        parts=re.split(r'(?=^###\s+)',section(text,'## Объекты метаданных'),flags=re.M)
        is_register=lambda part:bool(re.match(mappings['accumulationHeadingPattern'],part,re.I))
        source['sections']['Регистры накопления']='\n\n'.join(p for p in parts if is_register(p))
        source['sections']['Прочие объекты']='\n\n'.join(p for p in parts if not is_register(p))
        source['images']={}
        for target in set(re.findall(r'!\[\[([^\]]+)\]\]','\n'.join(source['sections'].values()))):
            path,issue=resolve_attachment(vault,ticket.path,target)
            source['images'][target]={'asset':asset(path.read_bytes(),path.suffix)} if path and path.suffix.lower() in ('.png','.jpg','.jpeg','.webp') else {'issue':issue or 'Формат не поддерживается'}
        item['source']=source;item['images']={}
        for target in set(re.findall(r'!\[\[([^\]]+)\]\]',ticket.condition)):
            path,issue=resolve_attachment(vault,ticket.path,target)
            item['images'][target]={'asset':asset(path.read_bytes(),path.suffix)} if path and path.suffix.lower() in ('.png','.jpg','.jpeg','.webp') else {'issue':issue or 'Формат не поддерживается'}
        key=f'{ticket.section}:{"доп" if item["additional"] else ""}{ticket.number}'
        item['frequency']=frequency['counts'].get(key,0) if frequency['records'] else None
        # References stay explicit: unavailable source sections are not replaced by another ticket.
        audit.append({'ticket':ticket.title,'exercises':len(item['exercises']),'sections':{k:bool(v and v!='В заметке нет этого раздела; эталон не добавлялся.') for k,v in source['sections'].items()}})
        item['note_version']=ticket.version
        attachment_ids=sorted(image['asset'] for image in [*item['images'].values(),*source['images'].values()] if image.get('asset'))
        item['version']=sha(encoded([ticket.version,attachment_ids,{'exercise_format':2,'section_mapping':1}]))
        source['version']=item['version']
        result.append(item)
    library=build_library(vault,asset)
    data=dict(format=1,id=sha(encoded([(t['id'],t['version']) for t in result])+encoded(frequency)+encoded(seed)+encoded([(n['id'],n['version']) for n in library])),createdAt=datetime.now(timezone.utc).isoformat(),tickets=result,seed=seed,frequency=frequency,assets=assets,library=library)
    files['materials.json']=encoded(data)
    manifest={'format':1,'files':{name:sha(content) for name,content in files.items()}}
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json',encoded(manifest))
        for name,content in files.items():z.writestr(name,content)
    output.with_suffix('.audit.json').write_bytes(encoded(audit))
    print(json.dumps({'tickets':len(result),'exercises':sum(len(t['exercises']) for t in result),'notes':len(library),'frequency_records':frequency['records'],'assets':len(assets),'zip_bytes':output.stat().st_size,'output':str(output)},ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--vault',type=Path,required=True);p.add_argument('--excel',type=Path,required=True);p.add_argument('--docx',type=Path,required=True);p.add_argument('--output',type=Path,default=ROOT/'web/private/materials.zip')
    a=p.parse_args();export(a.vault,a.excel,a.docx,a.output)
