import hashlib,json,sys,unittest,zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
sys.path.insert(0,str(Path(__file__).parent))
from accounting_docs import FILES,read_tables,NS,W,attach_references
ROOT=Path(__file__).resolve().parents[2]
FOLDER=Path('D:/1с специалист/таблицы по БУ')

@unittest.skipUnless(FOLDER.is_dir(),'Private Word examples')
class AccountingTests(unittest.TestCase):
    def test_all_documents_and_grid(self):
        for filename in FILES.values():
            path=FOLDER/filename;reference=read_tables(path)
            self.assertEqual(reference['version'],hashlib.sha256(path.read_bytes()).hexdigest())
            with zipfile.ZipFile(path) as z:xml=ET.fromstring(z.read('word/document.xml'))
            expected=[]
            for cell in xml.findall('.//w:tbl/w:tr/w:tc',NS):
                merge=cell.find('w:tcPr/w:vMerge',NS)
                if merge is not None and merge.get(W+'val')!='restart':continue
                expected.append('\n'.join(''.join((node.text or '') if node.tag==W+'t' else '\n' if node.tag==W+'br' else '\t' if node.tag==W+'tab' else '' for node in p.iter()) for p in cell.findall('w:p',NS)))
            actual=[c['text'] for table in reference['tables'] for row in table for c in row if not c.get('omitted')]
            self.assertEqual(actual,expected,filename)
            for table in reference['tables']:
                grid=[[False]*5 for _ in table]
                for ri,row in enumerate(table):
                    for cell in row:
                        for r in range(ri,ri+cell['rowSpan']):
                            for c in range(cell['column'],cell['column']+cell['colSpan']):
                                self.assertFalse(grid[r][c],filename);grid[r][c]=True
                self.assertTrue(all(all(row) for row in grid),filename)
    def test_mapping_versioning_and_hashes(self):
        with zipfile.ZipFile(ROOT/'web/private/materials.zip') as z:data=json.loads(z.read('materials.json'))
        referenced=[t for t in data['tickets'] if t.get('accountingReference')]
        self.assertEqual(len(referenced),18)
        self.assertFalse(next(t for t in data['tickets'] if t['section']=='БУ' and t['number']==6 and not t['additional']).get('accountingReference'))
        versions=[t['version'] for t in data['tickets']]
        attach_references(data['tickets'],FOLDER)
        self.assertEqual(versions,[t['version'] for t in data['tickets']])
        for t in referenced:
            self.assertEqual(t['accountingReference']['source'],FILES[t['number'],t['additional']])
            expected=hashlib.sha256((t['accounting_base_version']+'\naccounting-docx-v1\n'+t['accountingReference']['version']).encode('utf-8')).hexdigest()
            self.assertEqual(t['version'],expected)
        for path,digest in json.loads((ROOT/'web/private/accounting-docs-before.json').read_text(encoding='utf-8')).items():self.assertEqual(hashlib.sha256(Path(path).read_bytes()).hexdigest(),digest)

if __name__=='__main__':unittest.main()
