"""Draw the app's code-native notebook icon; no external assets or packages."""
from pathlib import Path
import struct,zlib

def create(size):
    def segment(x,y,a,b,width):
        dx,dy=b[0]-a[0],b[1]-a[1]
        t=max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy)))
        return (x-a[0]-t*dx)**2+(y-a[1]-t*dy)**2<width**2
    pixels=bytearray()
    for y in range(size):
        pixels.append(0)
        for x in range(size):
            xx,yy=x*192/size,y*192/size;c=(255,211,72)
            if 46<=xx<=146 and 52<=yy<=141:c=(255,249,220)
            if any(segment(xx,yy,a,b,4.5) for a,b in [((67,77),(125,77)),((67,96),(125,96)),((67,115),(101,115))]):c=(52,56,47)
            if any(segment(xx,yy,a,b,5.5) for a,b in [((110,132),(122,144)),((122,144),(148,115))]):c=(183,35,44)
            pixels.extend((*c,255))
    def chunk(name,data):return struct.pack('>I',len(data))+name+data+struct.pack('>I',zlib.crc32(name+data)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(pixels))+chunk(b'IEND',b'')
if __name__=='__main__':
    folder=Path(__file__).resolve().parents[1]/'public'
    for size in (180,192,512):(folder/f'icon-{size}.png').write_bytes(create(size))
