"""Read-only Markdown library with explicit local links; no recursive embeds."""
import hashlib,re
from pathlib import Path
from trainer.parser import resolve_attachment

def outside_code(text):
    lines=[];opened=None
    for line in text.splitlines(keepends=True):
        fence=re.match(r'^ {0,3}(`{3,}|~{3,})(.*)$',line)
        if opened:
            if fence and fence[1][0]==opened[0] and len(fence[1])>=len(opened) and not fence[2].strip():opened=None
            lines.append('\n');continue
        if fence:opened=fence[1];lines.append('\n');continue
        lines.append(re.sub(r'(`+).*?\1','',line))
    return ''.join(lines)

def build_library(vault,asset):
    root=vault.resolve()
    paths=sorted(p for p in vault.rglob('*.md') if '.obsidian' not in p.relative_to(vault).parts and p.resolve().is_relative_to(root))
    by_path={p.relative_to(vault).as_posix():p for p in paths}
    def resolve(current,target):
        name,_,heading=target.partition('#');name=name.strip()
        if not name:return current,heading,''
        if not name.lower().endswith('.md'):name+='.md'
        for candidate in (root/Path(current).parent/name,root/name):
            resolved=candidate.resolve()
            if resolved.is_relative_to(root) and resolved.relative_to(root).as_posix() in by_path:return resolved.relative_to(root).as_posix(),heading,''
        matches=[path for path in by_path if Path(path).name==Path(name).name]
        if len(matches)==1:return matches[0],heading,''
        return None,heading,'Заметка не найдена или имя неоднозначно: '+target
    result=[]
    for relative,path in by_path.items():
        raw=path.read_bytes();text=raw.decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n')
        visible=outside_code(text);images={};links={};warnings=[]
        for m in re.finditer(r'(!?)\[\[([^\]]+)\]\]',visible):
            embedded,body=m.groups();target=body.split('|',1)[0]
            resolved,heading,issue=resolve(relative,target)
            if resolved:links[target]={'id':resolved,'heading':heading}
            elif not embedded:links[target]={'issue':issue}
            if embedded and not resolved:
                image,problem=resolve_attachment(vault,relative,target)
                images[body]={'asset':asset(image.read_bytes(),image.suffix)} if image and image.suffix.lower() in ('.png','.jpg','.jpeg','.webp') else {'issue':problem or 'Вложение не отображается в читалке: '+target}
                if 'issue' in images[body]:warnings.append(images[body]['issue'])
        for target in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',visible):
            image,problem=resolve_attachment(vault,relative,target)
            images[target]={'asset':asset(image.read_bytes(),image.suffix)} if image and image.suffix.lower() in ('.png','.jpg','.jpeg','.webp') else {'issue':problem or 'Вложение не отображается: '+target}
        title=re.search(r'^#\s+(.+?)\s*$',visible,re.M)
        version=hashlib.sha256(raw+'\n'.join(sorted(i['asset'] for i in images.values() if i.get('asset'))).encode('utf-8')).hexdigest()
        result.append(dict(id=relative,path=relative,title=title[1] if title else path.stem,folder=Path(relative).parent.as_posix() if '/' in relative else 'Общие заметки',version=version,content=text,images=images,links=links,warnings=warnings))
    return result
