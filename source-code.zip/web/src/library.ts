import type {LibraryNote} from './types';
export const headingId=(text:string)=>text.trim().toLocaleLowerCase().replace(/[^\p{L}\p{N}\s_-]/gu,'').replace(/\s+/g,'-');
export const noteUrl=(id:string,heading='')=>'#theory/'+encodeURIComponent(id)+(heading?'?section='+encodeURIComponent(heading):'');
export function headings(text:string){
  const result:{level:number;title:string;id:string}[]=[];let fence='';const counts:Record<string,number>={};
  for(const line of text.split('\n')){const marker=/^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);if(fence){if(marker&&marker[1][0]===fence[0]&&marker[1].length>=fence.length&&!marker[2].trim())fence='';continue;}if(marker){fence=marker[1];continue;}const h=/^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(line);if(h){const title=h[2].replace(/[*`_]/g,''),base=headingId(title),n=counts[base]||0;counts[base]=n+1;result.push({level:h[1].length,title,id:base+(n?'-'+n:'')});}}
  return result;
}
type Node={type:string;value?:string;url?:string;children?:Node[];alt?:string};
/** Transform only Markdown text nodes. Literals, fenced code and inline code are untouched. */
export function wikiPlugin(links:LibraryNote['links'],images:LibraryNote['images']){
  return ()=> (tree:Node)=>{
    const walk=(node:Node)=>{if(!node.children)return;node.children=node.children.flatMap(child=>{
      if(child.type!=='text'){if(child.type!=='code'&&child.type!=='inlineCode'&&child.type!=='link')walk(child);return [child];}
      const text=child.value||'',parts:Node[]=[];let last=0;
      for(const match of text.matchAll(/(!?)\[\[([^\]]+)\]\]/g)){
        if(match.index!>last)parts.push({type:'text',value:text.slice(last,match.index)});
        const raw=match[2],[target,label]=raw.split('|'),entry=links[target],shown=label||target;
        if(match[1]&&images[raw])parts.push({type:'image',url:'/__local_image__/'+encodeURIComponent(raw),alt:shown});
        else if(entry?.id)parts.push({type:'link',url:noteUrl(entry.id,entry.heading),children:[{type:'text',value:(match[1]?'Открыть заметку: ':'')+shown}]});
        else parts.push({type:'link',url:'/__missing_note__/'+encodeURIComponent(target),children:[{type:'text',value:shown}]});
        last=match.index!+match[0].length;
      }
      if(last<text.length)parts.push({type:'text',value:text.slice(last)});
      return parts.length?parts:[child];
    });};walk(tree);
  };
}
