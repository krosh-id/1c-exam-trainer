// @vitest-environment jsdom
import React from 'react';
import {afterEach,it,expect,vi} from 'vitest';
import {render,screen,cleanup} from '@testing-library/react';
import {Note} from './components';
import {TheoryReader} from './TheoryReader';
import {headings,noteUrl} from './library';
import type {Materials,LibraryNote} from './types';
const note:LibraryNote={id:'Теория/a.md',path:'Теория/a.md',folder:'Теория',title:'Блокировки',version:'v',content:'# Заголовок\n\n[[Другой|Перейти]]\n\n```\nЕсли Истина Тогда\n// [[Не ссылка]]\nКонецЕсли;\n```\n\n`[[Литерал]]`',links:{Другой:{id:'b.md'}},images:{},warnings:[]};
const m={library:[note],assets:{}} as Materials;
afterEach(cleanup);
it('не вкладывает параграф в параграф при недоступном изображении',()=>{const errors=vi.spyOn(console,'error').mockImplementation(()=>{});try{const {container}=render(<Note text="![[missing.png]]" images={{'missing.png':{asset:'missing'}}} m={m} t={note}/>);expect(screen.getByText(/Изображение недоступно/)).toBeTruthy();expect(container.querySelector('p p')).toBeNull();expect(errors).not.toHaveBeenCalled();}finally{errors.mockRestore();}});
it('подсвечивает код, сохраняет литералы и преобразует только ссылки текста',()=>{const {container}=render(<Note text={note.content} images={{}} m={m} t={note}/>);expect(screen.getByRole('link',{name:'Перейти'}).getAttribute('href')).toBe(noteUrl('b.md'));expect(container.querySelector('.code')?.textContent).toBe('Если Истина Тогда\n// [[Не ссылка]]\nКонецЕсли;');expect(container.querySelector('.keyword')?.textContent).toBe('Если');expect(container.querySelectorAll('a')).toHaveLength(1);expect(screen.getByText('[[Литерал]]')).toBeTruthy();});
it('оглавление не читает заголовки внутри кода и различает повторы',()=>{expect(headings('# Один\n```\n# Скрытый\n```\n## Один')).toEqual([{level:1,title:'Один',id:'один'},{level:2,title:'Один',id:'один-1'}]);});
it('показывает библиотеку и предупреждение для старого пакета',()=>{const view=render(<TheoryReader m={m} route="theory"/>);expect(screen.getByRole('link',{name:/Блокировки/})).toBeTruthy();view.rerender(<TheoryReader m={{...m,library:undefined}} route="theory"/>);expect(screen.getByText(/В этом пакете пока нет библиотеки/)).toBeTruthy();});
