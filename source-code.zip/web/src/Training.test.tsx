// @vitest-environment jsdom
import React from 'react';
import {afterEach,describe,it,expect,vi} from 'vitest';
import {render,screen,fireEvent,waitFor,cleanup} from '@testing-library/react';
import {Training} from './Training';
import {saveRecord} from './db';
import {newObject,schema} from './model';
import {DesignEditor} from './DesignEditor';
import {createRecord,newDesign,stages} from './logic';
import type {Materials,RecordItem,Ticket} from './types';
vi.mock('./db',()=>({attachAssets:async()=>{},download:vi.fn(),saveRecord:vi.fn(async(r:RecordItem)=>({...r,revision:r.revision+1,updatedAt:new Date().toISOString()}))}));
const ticket:Ticket={id:'test-ui',section:'ОУ',number:1,additional:false,title:'Учебный билет',path:'t.md',version:'v1',condition:'Только условие',fragments:[{id:'f',title:'Фрагмент',code:'Перем А;',start_line:1,end_line:1,language:''}],exercises:[{id:'e',title:'Модуль',fragment_id:'f',kind:'module',cards:[{id:'a',source:'А();',display:'А();',query_label:''},{id:'b',source:'Б();',display:'Б();',query_label:''}]}],source:{path:'t.md',version:'v1',images:{},sections:{'Прочие объекты':'СКРЫТЫЙ ЭТАЛОН','Регистры накопления':'СКРЫТЫЙ РЕГИСТР'}},images:{},warnings:[],frequency:0};
const materials={format:1,id:'m',createdAt:'2026-01-01',tickets:[ticket],seed:{version:1,provenance:'Учебная заготовка',objects:{ОУ:[newObject('Справочник','Товары')],БУ:[],СПР:[]},accounting_rows:[]},assets:{},frequency:{source:'example.xlsx',records:1,period_start:'2026-01-01',period_end:'2026-01-01',counts:{}}} as Materials;
afterEach(()=>{cleanup();vi.mocked(saveRecord).mockImplementation(async(r:RecordItem)=>({...r,revision:r.revision+1,updatedAt:new Date().toISOString()}));});
describe('Режимы и восстановление интерфейса',()=>{
  it('переключает запросы и фрагменты после асинхронного сохранения',async()=>{
    const t={...ticket,id:'query-switch',exercises:[...ticket.exercises,...['q1','q2'].map(id=>({...ticket.exercises[0],id,title:id,kind:'query' as const}))]};
    vi.mocked(saveRecord).mockImplementation(async r=>{await new Promise(resolve=>setTimeout(resolve,30));return {...r,revision:r.revision+1};});
    render(<Training t={t} m={materials} records={[]} onSaved={()=>{}} onBack={()=>{}}/>);
    const selector=await screen.findByRole('combobox',{name:'Модули или запросы'});
    fireEvent.change(selector,{target:{value:'query'}});
    await waitFor(()=>expect((screen.getByRole('combobox',{name:'Фрагмент сборки'}) as HTMLSelectElement).value).toBe('q1'));
    fireEvent.change(screen.getByRole('combobox',{name:'Фрагмент сборки'}),{target:{value:'q2'}});
    await waitFor(()=>expect((screen.getByRole('combobox',{name:'Фрагмент сборки'}) as HTMLSelectElement).value).toBe('q2'));
    fireEvent.change(screen.getByRole('combobox',{name:'Модули или запросы'}),{target:{value:'module'}});
    await waitFor(()=>expect((screen.getByRole('combobox',{name:'Фрагмент сборки'}) as HTMLSelectElement).value).toBe('e'));
  });
  it('переходит из сборки в память и проектирование без чужого состояния',async()=>{render(<Training t={ticket} m={materials} records={[]} onSaved={()=>{}} onBack={()=>{}}/>);fireEvent.click(await screen.findByRole('button',{name:'Билет по памяти'}));await screen.findByRole('textbox',{name:'Ваш код'});fireEvent.change(screen.getByRole('textbox',{name:'Ваш код'}),{target:{value:'Перем А;'}});fireEvent.click(screen.getByRole('button',{name:'Отправить и открыть эталоны'}));await screen.findByRole('heading',{name:'✓ Точное совпадение'});fireEvent.click(screen.getByRole('button',{name:'Спроектируй решение'}));await screen.findByRole('heading',{name:'Прочие объекты'});expect(screen.queryByText('СКРЫТЫЙ ЭТАЛОН')).toBeNull();});
  it('раскрывает эталон только после этапа, сохраняет самооценку',()=>{let r=createRecord(ticket,'design');r.state=newDesign(materials,ticket);const fn=vi.fn((next:RecordItem)=>{r=next;view.rerender(<DesignEditor record={r} onChange={fn} m={materials} t={ticket}/>);});const view=render(<DesignEditor record={r} onChange={fn} m={materials} t={ticket}/>);expect(screen.queryByText('СКРЫТЫЙ ЭТАЛОН')).toBeNull();expect((screen.getByRole('button',{name:'2. Регистры накопления'}) as HTMLButtonElement).disabled).toBe(true);fireEvent.click(screen.getByRole('button',{name:'Завершить этап и открыть эталон'}));expect(screen.getByText('СКРЫТЫЙ ЭТАЛОН')).toBeTruthy();fireEvent.click(screen.getByRole('button',{name:'3 Почти всё'}));expect(r.state!.stages['Прочие объекты'].rating).toBe(3);expect(r.viewed).toBe(true);});
  it('дожидается самооценки, изменённой во время предыдущей записи',async()=>{const t={...ticket,id:'save-queue'};const saved:RecordItem[]=[];const back=vi.fn();render(<Training t={t} m={materials} records={[]} onSaved={r=>saved.push(r)} onBack={back}/>);fireEvent.click(await screen.findByRole('button',{name:'Билет по памяти'}));await screen.findByRole('textbox',{name:'Ваш код'});vi.mocked(saveRecord).mockImplementation(async(r:RecordItem)=>{await new Promise(resolve=>setTimeout(resolve,30));return {...r,revision:r.revision+1,updatedAt:new Date().toISOString()};});fireEvent.click(screen.getByRole('button',{name:'Отправить и открыть эталоны'}));fireEvent.click(await screen.findByRole('button',{name:'4 Полностью'}));fireEvent.click(screen.getByRole('button',{name:'← Все билеты'}));await waitFor(()=>expect(back).toHaveBeenCalledTimes(1));expect(saved.at(-1)).toMatchObject({mode:'memory',submitted:true,rating:4});});
  it('удерживает ввод при ошибке записи и после перехода в другой экран',async()=>{const t={...ticket,id:'write-failure'};const props={t,m:materials,records:[],onSaved:()=>{},onBack:()=>{}};let view=render(<Training {...props}/>);fireEvent.click(await screen.findByRole('button',{name:'Билет по памяти'}));await screen.findByRole('textbox',{name:'Ваш код'});vi.mocked(saveRecord).mockRejectedValue(new Error('Недостаточно места'));fireEvent.change(screen.getByRole('textbox',{name:'Ваш код'}),{target:{value:'Мой несохранённый ответ'}});await screen.findByRole('alert');expect((screen.getByRole('textbox',{name:'Ваш код'}) as HTMLTextAreaElement).value).toBe('Мой несохранённый ответ');view.unmount();view=render(<Training {...props}/>);fireEvent.click(await screen.findByRole('button',{name:'Билет по памяти'}));await waitFor(()=>expect((screen.getByRole('textbox',{name:'Ваш код'}) as HTMLTextAreaElement).value).toBe('Мой несохранённый ответ'));});
  it('показывает всех владельцев флажками и сохраняет ссылки при выборе',()=>{
    let r=createRecord(ticket,'design');r.state={...newDesign(materials,ticket),objects:['Товары','Партии','Склады'].map(n=>newObject('Справочник',n))};
    const onChange=(next:RecordItem)=>{r=next;view.rerender(<DesignEditor record={r} onChange={onChange} m={materials} t={ticket}/>);};
    const view=render(<DesignEditor record={r} onChange={onChange} m={materials} t={ticket}/>);
    const owner=screen.getByRole('checkbox',{name:'Справочник: Партии'});fireEvent.click(owner);
    expect(r.state!.objects[0].properties.owners).toEqual([{$ref:r.state!.objects[1].id}]);
    fireEvent.click(screen.getByRole('checkbox',{name:'Справочник: Склады'}));
    expect(r.state!.objects[0].properties.owners).toHaveLength(2);
    fireEvent.click(screen.getByRole('checkbox',{name:'Справочник: Партии'}));
    expect(r.state!.objects[0].properties.owners).toEqual([{$ref:r.state!.objects[2].id}]);
  });
  it('скрывает Word до завершения этапа и восстанавливает составленную схему',()=>{
    const t={...ticket,section:'БУ',accountingReference:{source:'1.docx',version:'ref-v1',tables:[[[{column:0,text:'СЕКРЕТНАЯ ТАБЛИЦА',rowSpan:1,colSpan:5}]]]}};
    let r=createRecord(t,'design');r.state=newDesign(materials,t);
    const onChange=(next:RecordItem)=>{r=next;view.rerender(<DesignEditor record={r} onChange={onChange} m={materials} t={t}/>);};
    let view=render(<DesignEditor record={r} onChange={onChange} m={materials} t={t}/>);
    expect(screen.queryByText('СЕКРЕТНАЯ ТАБЛИЦА')).toBeNull();
    fireEvent.change(screen.getByRole('textbox',{name:'Показатель 1'}),{target:{value:'Мой показатель'}});
    fireEvent.click(screen.getByRole('button',{name:'Завершить этап и открыть эталон'}));
    expect(screen.getByText('СЕКРЕТНАЯ ТАБЛИЦА')).toBeTruthy();
    fireEvent.click(screen.getByRole('button',{name:'4 Полностью'}));
    expect(r.state!.stages['Схема учёта'].rating).toBe(4);
    view.unmount();view=render(<DesignEditor record={r} onChange={onChange} m={materials} t={t}/>);
    fireEvent.click(screen.getByRole('button',{name:/1. Схема учёта/}));
    expect((screen.getByRole('textbox',{name:'Показатель 1'}) as HTMLTextAreaElement).value).toBe('Мой показатель');
    expect(screen.getByText('СЕКРЕТНАЯ ТАБЛИЦА')).toBeTruthy();
  });
  it('редактирует имя и строки таблиц каждого типа объектов',()=>{for(const kind of schema.kinds){const t={...ticket,section:'БУ'},m={...materials,seed:{...materials.seed,objects:{...materials.seed.objects,БУ:[newObject(kind,'Объект')]}}};let r=createRecord(t,'design');r.state=newDesign(m,t);r.state.stages['Схема учёта']={completed:true,viewed:true,rating:3};const onChange=(next:RecordItem)=>{r=next;view.rerender(<DesignEditor record={r} onChange={onChange} m={m} t={t}/>);};const view=render(<DesignEditor record={r} onChange={onChange} m={m} t={t}/>);fireEvent.click(screen.getByRole('button',{name:'2. Объекты метаданных'}));expect(screen.getByRole('heading',{name:new RegExp('Объект.*'+kind)})).toBeTruthy();fireEvent.change(screen.getByRole('textbox',{name:'Новое имя объекта'}),{target:{value:'НовоеИмя'}});fireEvent.click(screen.getByRole('button',{name:'Переименовать'}));expect(r.state!.objects[0].name).toBe('НовоеИмя');const tables=schema.definitions[kind][1],first=Object.keys(tables)[0];if(first){const button=view.container.querySelector('.object-detail .row-editor button')!;fireEvent.click(button);const nameField=tables[first].name;if(nameField)fireEvent.change(screen.getByRole('textbox',{name:nameField.label}),{target:{value:'УчебноеПоле'}});fireEvent.click(screen.getByRole('button',{name:'Применить'}));expect(r.state!.objects[0].tables[first]).toHaveLength(1);expect(r.state!.objects[0].tables[first][0].name).toBe('УчебноеПоле');}view.unmount();}});
  it('сохраняет форму при запрещённом удалении связанного объекта',()=>{const cat=newObject('Справочник','Товары'),doc=newObject('Документ','Накладная');doc.tables.attributes=[{id:'f',name:'Номенклатура',type:{$ref:cat.id}}];const r=createRecord(ticket,'design');r.state={...newDesign(materials,ticket),objects:[cat,doc]};const onChange=vi.fn();render(<DesignEditor record={r} onChange={onChange} m={materials} t={ticket}/>);fireEvent.click(screen.getByRole('button',{name:'Удалить'}));expect(screen.getByRole('alert').textContent).toContain('используется удалённый объект');expect(onChange).not.toHaveBeenCalled();});
});

