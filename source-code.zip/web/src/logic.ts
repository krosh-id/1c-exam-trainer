import type {Card,DesignState,Exercise,Materials,Mode,RecordItem,Ticket} from './types';
export function normalize(code:string):string {
  let quoted=false;
  const lines=code.replace(/\r\n?/g,'\n').split('\n').map(line=>{
    const began=quoted;
    for(let i=0;i<line.length;i++){
      if(!quoted&&line.slice(i,i+2)==='//')break;
      if(line[i]==='"'){if(quoted&&line[i+1]==='"'){i++;continue;}quoted=!quoted;}
    }
    if(!began)line=line.replace(/^[ \t]+/,'');
    if(!quoted)line=line.replace(/[ \t]+$/,'');
    return line;
  });
  while(lines.length&&lines[0]==='')lines.shift();while(lines.length&&lines.at(-1)==='')lines.pop();
  return lines.join('\n');
}
export function gradeOrder(ex:Exercise,ids:string[]){
  if(ids.length!==ex.cards.length||new Set(ids).size!==ids.length||ids.some(id=>!ex.cards.some(c=>c.id===id)))throw Error('В сборке должны быть все карточки, каждая ровно один раз.');
  const key=(c:Card)=>JSON.stringify([ex.kind==='query'?c.display.trim():normalize(c.display),c.query_label]);
  return ids.map((id,i)=>key(ex.cards.find(c=>c.id===id)!)===key(ex.cards[i]));
}
export function shuffle(ex:Exercise){
  const ids=ex.cards.map(c=>c.id);
  for(let i=ids.length-1;i>0;i--){const j=crypto.getRandomValues(new Uint32Array(1))[0]%(i+1);[ids[i],ids[j]]=[ids[j],ids[i]];}
  if(ids.length>1&&ids.every((id,i)=>id===ex.cards[i].id))ids.push(ids.shift()!);
  return ids;
}
export const stages=(section:string)=>section==='ОУ'?['Прочие объекты','Регистры накопления']:section==='БУ'?['Схема учёта','Объекты метаданных']:['Формулы и источники','Таблица зависимостей','Объекты метаданных'];
export const newDesign=(m:Materials,t:Ticket):DesignState=>({section:t.section,objects:structuredClone(m.seed.objects[t.section]),accounting:t.section==='БУ'?structuredClone(m.seed.accounting_rows):[],formulas:[],variables:[],dependencies:[],stages:{}});
export function createRecord(t:Ticket,mode:Mode,unit?:string):RecordItem{return {id:crypto.randomUUID(),ticketId:t.id,version:t.version,mode,unit,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),revision:0,submitted:false,answers:{},snapshot:structuredClone(t)};}
export const designDone=(r:RecordItem)=>!!r.state&&stages(r.snapshot.section).every(s=>r.state!.stages[s]?.completed&&r.state!.stages[s]?.rating);
export const completed=(r:RecordItem)=>r.mode==='design'?designDone(r):r.submitted&&(r.mode!=='memory'||!!r.rating);
export const available=(t:Ticket):Mode[]=>[...(t.exercises.length?['order' as Mode]:[]),...(t.fragments.some(f=>f.code.trim())?['memory' as Mode]:[]),'design'];
export function status(t:Ticket,records:RecordItem[],mode?:Mode){
  const current=records.filter(r=>r.ticketId===t.id&&r.version===t.version);
  const done=(m:Mode)=>m==='order'?t.exercises.every(e=>current.some(r=>r.mode===m&&r.unit===e.id&&r.submitted)):current.some(r=>r.mode===m&&completed(r));
  if(mode&&!available(t).includes(mode))return 'Нет листинга';
  if((mode?[mode]:available(t)).every(done))return 'Пройден';
  if(current.some(r=>!mode||r.mode===mode))return 'Начат';
  if(records.some(r=>r.ticketId===t.id&&(!mode||r.mode===mode)))return 'Материалы обновлены';
  return 'Не начат';
}
export function aggregate(tickets:Ticket[],records:RecordItem[],mode?:Mode){
  tickets=mode?tickets.filter(t=>available(t).includes(mode)):tickets;
  const rs=records.filter(r=>tickets.some(t=>t.id===r.ticketId&&t.version===r.version)&&(!mode||r.mode===mode));
  const attempts=rs.filter(completed),checked=rs.filter(r=>r.submitted&&r.mode!=='design');
  return {total:tickets.length,started:tickets.filter(t=>status(t,rs,mode)==='Начат'||status(t,rs,mode)==='Пройден').length,done:tickets.filter(t=>status(t,rs,mode)==='Пройден').length,attempts:attempts.length,exact:checked.length?Math.round(100*checked.filter(r=>r.correct).length/checked.length):null,ratings:[1,2,3,4].map(n=>rs.reduce((sum,r)=>sum+(r.mode==='design'?Object.values(r.state?.stages||{}).filter(s=>s.rating===n).length:r.rating===n?1:0),0))};
}
