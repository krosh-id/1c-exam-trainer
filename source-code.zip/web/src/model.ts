import raw from './schema.json';
import type {DesignState,MetaObject,Row,Schema,Spec} from './types';
export const schema=raw as unknown as Schema;
export const ref=(value:any):string|undefined=>value&&typeof value==='object'?value.$ref:undefined;
export const encode=(v:any):string=>ref(v)?(v.flavor?'characteristic:':'')+v.$ref:v??'';
export function index(s:DesignState){const result:Record<string,{value:any;label:string}>={};for(const o of s.objects){result[o.id]={value:o,label:o.kind+': '+o.name};for(const [table,rows] of Object.entries(o.tables))for(const r of rows)result[r.id]={value:r,label:o.name+' / '+(schema.tableNames[table]||table)+' / '+(r.name||r.id.slice(0,6))};}return result;}
export const decode=(v:string,s:DesignState):any=>!v?null:v.startsWith('characteristic:')?{$ref:v.slice(15),flavor:'Характеристика'}:index(s)[v]?{$ref:v}:v;
export function options(s:DesignState,o:MetaObject,target=''):Record<string,string>{
  const idx=index(s),objects=s.objects;
  const rows=(owner:any,table:string):Row[]=>owner?.tables?.[table]||[];
  const linked=(p:string)=>idx[ref(o.properties[p])||'']?.value;
  const map=(items:any[])=>Object.fromEntries(items.map(v=>[v.id,idx[v.id]?.label||v.name]));
  if(target==='types')return Object.fromEntries([...'Число Строка Дата Булево'.split(' ').map(v=>[v,v]),...objects.filter(v=>['Справочник','Документ','Перечисление','План видов характеристик'].includes(v.kind)).flatMap(v=>[[v.id,v.kind+'Ссылка.'+v.name],...(v.kind==='План видов характеристик'?[['characteristic:'+v.id,'Характеристика.'+v.name]]:[])])]);
  if(target.startsWith('objects:'))return map(objects.filter(v=>target.slice(8).split('|').includes(v.kind)));
  if(target.startsWith('local:'))return map(rows(o,target.slice(6)));
  if(target.startsWith('graph:'))return map(rows(linked('graph'),target.slice(6)));
  if(target.startsWith('plan:'))return map(rows(linked('plan'),target.slice(5)));
  if(target==='chart:subaccounts')return map(rows(linked('pvh'),'predefined'));
  if(target==='pvr:all')return map(objects.filter(v=>v.kind==='План видов расчёта').flatMap(v=>rows(v,'kinds')));
  if(target==='pvr:base'){if(!['По периоду действия','По периоду регистрации'].includes(o.properties.base_dependency))return {};const selected=(o.properties.base_plans||[]).map(ref);return map(objects.filter(v=>selected.includes(v.id)).flatMap(v=>rows(v,'kinds')));}
  if(target==='pvh:additional')return map(objects.filter(v=>v.kind==='Справочник'&&(v.properties.owners||[]).map(ref).includes(o.id)));
  if(target==='pvh:types'){const allowed=(o.properties.value_types||[]).map(encode);if(ref(o.properties.additional))allowed.push(ref(o.properties.additional));return Object.fromEntries(Object.entries(options(s,o,'types')).filter(([k])=>allowed.includes(k)));}
  if(target==='calculation:fields')return map(objects.filter(v=>v.kind==='Регистр расчёта').flatMap(v=>['dimensions','attributes'].flatMap(t=>rows(v,t))));
  if(target==='fields')return map(['attributes','dimensions','resources','part_fields'].flatMap(t=>rows(o,t)));
  if(target==='allfields')return map(objects.flatMap(v=>['attributes','dimensions','resources','part_fields'].flatMap(t=>rows(v,t))));
  if(target==='choice:targets'){const field=idx[ref(o.properties._choice_field)||'']?.value,owner=idx[ref(field?.type)||'']?.value;return map(['attributes','dimensions','resources','part_fields'].flatMap(t=>rows(owner,t)));}
  return {};
}
export const newObject=(kind:string,name:string):MetaObject=>{const [props,tables]=schema.definitions[kind];return {id:crypto.randomUUID(),kind,name,properties:Object.fromEntries(Object.entries(props).map(([k,v])=>[k,v.kind==='refs'?[]:null])),tables:Object.fromEntries(Object.keys(tables).map(k=>[k,[]])),choice_links:[]};};
export function references(v:any,path=''):Array<[string,string]>{if(!v||typeof v!=='object')return [];if(v.$ref)return [[v.$ref,path]];return Object.entries(v).flatMap(([k,x])=>references(x,path+'/'+k));}
export function validate(s:DesignState):string[]{
  const idx=index(s),errors:string[]=[],seen=new Set<string>();
  const check=(o:MetaObject,columns:Record<string,Spec>,row:any,label:string)=>{for(const [key,spec] of Object.entries(columns)){if(!['ref','refs'].includes(spec.kind))continue;const allowed=options(s,o,spec.target);const values=spec.kind==='refs'?row[key]||[]:[row[key]];for(const v of values)if(v!=null&&!(encode(v) in allowed))errors.push(label+' / '+spec.label+': ссылка недоступна.');}};
  if(s.objects.filter(o=>o.kind==='План счетов').length>1)errors.push('В конфигурации допускается один план счетов.');
  for(const o of s.objects){
    const key=o.kind+':'+o.name.trim().toLocaleLowerCase();if(!o.name.trim()||seen.has(key))errors.push('Имена объектов должны быть непустыми и уникальными внутри типа.');seen.add(key);
    for(const [target,path] of references(o))if(!idx[target])errors.push(o.name+path+': используется удалённый объект или поле '+target);
    const [props,tables]=schema.definitions[o.kind];check(o,props,o.properties,o.name);
    for(const [table,cols] of Object.entries(tables)){const names=new Set();for(const row of o.tables[table]||[]){if('name'in cols){const name=(ref(row.part)||ref(row.recalculation)||'')+':'+String(row.name||'').trim().toLocaleLowerCase();if(!row.name?.trim()||names.has(name))errors.push(o.name+' / '+schema.tableNames[table]+': имена строк должны быть непустыми и уникальными.');names.add(name);}if(row.type==='Число'&&((row.length!=null&&row.length<=0)||(row.precision!=null&&row.precision<0)||(row.length!=null&&row.precision!=null&&row.precision>row.length)))errors.push(o.name+': проверьте длину и точность числа.');check(o,cols,row,o.name+' / '+schema.tableNames[table]);}}
    for(const link of o.choice_links){const owned=options(s,o,'fields');if(!(ref(link.field)! in owned)||(link.source&&!(ref(link.source)! in owned)))errors.push(o.name+': связь должна принадлежать полю своего объекта.');if(link.target){const proxy={...o,properties:{...o.properties,_choice_field:link.field}};if(!(ref(link.target)! in options(s,proxy,'choice:targets')))errors.push(o.name+': назначение связи не принадлежит типу поля.');}}
  }
  const names=new Set(),ids=new Set(s.formulas.map(r=>r.id));for(const f of s.formulas){const n=String(f.name||'').trim().toLocaleLowerCase();if(!n||names.has(n))errors.push('Имена видов расчёта должны быть непустыми и уникальными.');names.add(n);}
  for(const [target,path] of references([...s.variables,...s.dependencies]))if(!ids.has(target))errors.push('Вид расчёта используется в '+path);
  return [...new Set(errors)];
}
