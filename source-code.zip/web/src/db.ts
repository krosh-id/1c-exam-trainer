import {validReference} from './accounting';
import {openDB} from 'idb';
import {unzipSync,strFromU8} from 'fflate';
import type {Materials,RecordItem} from './types';
import {validate} from './model';
const name='one-c-trainer:'+new URL(import.meta.env.BASE_URL,location.href).pathname;
const db=openDB(name,1,{upgrade(d){d.createObjectStore('materials');d.createObjectStore('records',{keyPath:'id'});d.createObjectStore('revisions',{keyPath:'key'});}});
export const readMaterials=async()=> (await db).get('materials','active') as Promise<Materials|undefined>;
export const readRecords=async()=> (await db).getAll('records') as Promise<RecordItem[]>;
export async function saveRecord(record:RecordItem){const d=await db,tx=d.transaction(['records','revisions'],'readwrite'),old=await tx.objectStore('records').get(record.id);if((old?.revision||0)!==record.revision){tx.abort();await tx.done.catch(()=>{});throw Error('Черновик изменён в другой вкладке. Ваш ввод сохранён в этом окне. Сохраните как новую попытку.');}const next={...record,revision:record.revision+1,updatedAt:new Date().toISOString()};await tx.objectStore('records').put(next);const {snapshot,...revision}=next;await tx.objectStore('revisions').put({key:next.id+':'+next.revision,record:revision,snapshotId:next.id});await tx.done;return next;}
const hash=async(bytes:Uint8Array)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(bytes).buffer))).map(b=>b.toString(16).padStart(2,'0')).join('');
export async function parsePackage(bytes:Uint8Array):Promise<Materials>{
  if(bytes.length>100*1024*1024)throw Error('Пакет слишком большой (максимум 100 МБ).');
  let size=0;const files=unzipSync(bytes,{filter:f=>{size+=f.originalSize;if(size>300*1024*1024)throw Error('Распакованный пакет превышает 300 МБ.');return true;}});
  if(!files['manifest.json']||!files['materials.json'])throw Error('Это не пакет материалов тренажёра.');
  const manifest=JSON.parse(strFromU8(files['manifest.json']));if(manifest.format!==1||typeof manifest.files!=='object')throw Error('Неподдерживаемая версия пакета.');
  for(const [name,expected] of Object.entries(manifest.files)){if(name.includes('..')||name.startsWith('/')||!files[name]||await hash(files[name])!==expected)throw Error('Повреждён файл пакета: '+name);}
  if(!manifest.files['materials.json'])throw Error('Материалы не включены в контрольные суммы.');
  const m=JSON.parse(strFromU8(files['materials.json']));if(m.format!==1||!Array.isArray(m.tickets)||!m.seed?.objects||!m.frequency||typeof m.id!=='string')throw Error('Некорректная структура материалов.');
  const ids=new Set();for(const t of m.tickets){if(!t.id||ids.has(t.id)||!['ОУ','БУ','СПР'].includes(t.section)||!Array.isArray(t.fragments)||!Array.isArray(t.exercises)||!t.source?.sections)throw Error('Некорректное задание.');ids.add(t.id);if(t.accountingReference&&!validReference(t.accountingReference))throw Error('Повреждена таблица Word.');for(const e of t.exercises){if(!Array.isArray(e.cards)||new Set(e.cards.map((c:any)=>c.id)).size!==e.cards.length)throw Error('Повреждено упражнение.');}for(const image of Object.values({...t.images,...t.source.images}) as any[])if(image.asset&&(!files[image.asset]||!manifest.files[image.asset]))throw Error('Отсутствует вложение.');}
  if(m.library!==undefined){
    if(!Array.isArray(m.library))throw Error('Некорректная библиотека заметок.');
    const noteIds=new Set<string>();for(const n of m.library){if(typeof n.id!=='string'||noteIds.has(n.id)||!['path','title','folder','version','content'].every(k=>typeof n[k]==='string')||!n.images||!n.links||!Array.isArray(n.warnings))throw Error('Повреждена заметка библиотеки.');noteIds.add(n.id);}
    for(const n of m.library){for(const link of Object.values(n.links) as any[])if(!link||link.id&&!noteIds.has(link.id))throw Error('Некорректная ссылка заметки.');for(const image of Object.values(n.images) as any[])if(!image||image.asset&&(!m.assets[image.asset]||!manifest.files[image.asset]||!files[image.asset]))throw Error('Отсутствует изображение заметки.');}
  }
  for(const [key,entry] of Object.entries(m.assets) as [string,any][]){if(!manifest.files[key]||!files[key]||!['image/png','image/jpeg','image/webp'].includes(entry.type))throw Error('Неподдерживаемое вложение '+key);entry.data=files[key];}
  for(const s of ['ОУ','БУ','СПР']){if(!Array.isArray(m.seed.objects[s]))throw Error('Отсутствует стартовая заготовка.');const errors=validate({section:s,objects:m.seed.objects[s],accounting:[],formulas:[],variables:[],dependencies:[],stages:{}});if(errors.length)throw Error('Некорректная заготовка: '+errors[0]);}
  return m;
}
export async function importPackage(bytes:Uint8Array){const m=await parsePackage(bytes);await (await db).put('materials',m,'active');return m;}
export async function exportProgress(){const d=await db;return JSON.stringify({format:1,kind:'one-c-progress',createdAt:new Date().toISOString(),records:await d.getAll('records'),revisions:await d.getAll('revisions')});}
export async function importProgress(text:string){
  const backup=JSON.parse(text);if(backup.format!==1||backup.kind!=='one-c-progress'||!Array.isArray(backup.records)||!Array.isArray(backup.revisions))throw Error('Неподдерживаемая резервная копия.');
  for(const r of backup.records){if(!r.id||!r.ticketId||!r.snapshot?.source||!Array.isArray(r.snapshot.fragments)||!Array.isArray(r.snapshot.exercises)||!['order','memory','design'].includes(r.mode)||!Number.isInteger(r.revision)||!r.answers||typeof r.answers!=='object')throw Error('Повреждена запись прогресса.');if(r.mode==='design'&&!r.state)throw Error('Отсутствует конфигурация попытки.');if(r.state&&validate(r.state).length)throw Error('Повреждена конфигурация.');}
  const fingerprints=await Promise.all(backup.records.map((r:RecordItem)=>hash(new TextEncoder().encode(JSON.stringify(r)))));
  const d=await db,tx=d.transaction(['records','revisions'],'readwrite');let added=0,conflicts=0;const remap=new Map();
  for(const [i,r] of backup.records.entries()){const old=await tx.objectStore('records').get(r.id);if(!old){await tx.objectStore('records').put(r);added++;}else if(JSON.stringify(old)!==JSON.stringify(r)){const id=r.id+':import:'+fingerprints[i].slice(0,16);remap.set(r.id,id);if(!await tx.objectStore('records').get(id)){await tx.objectStore('records').put({...r,id});conflicts++;}}}
  for(const rev of backup.revisions){if(!rev.record?.id)continue;const id=remap.get(rev.record.id)||rev.record.id;const value={...rev,key:id+':'+rev.record.revision,snapshotId:id,record:{...rev.record,id}};const old=await tx.objectStore('revisions').get(value.key);if(!old)await tx.objectStore('revisions').put(value);}
  await tx.done;return {added,conflicts};
}
export async function attachAssets(record:RecordItem,m:Materials){
  const ids=new Set(Object.values({...record.snapshot.images,...record.snapshot.source.images}).flatMap(i=>i.asset?[i.asset]:[]));
  // Snapshot image data is stored once per record revision only by IndexedDB, independent of the active package.
  const snap=record.snapshot as any;snap.archivedAssets ||= {};
  for(const id of ids)if(m.assets[id]&&!snap.archivedAssets[id])snap.archivedAssets[id]={type:m.assets[id].type,base64:toBase64(m.assets[id].data)};
}
export function toBase64(bytes:Uint8Array){let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.slice(i,i+8192));return btoa(s);}
export function download(content:string|Blob,name:string){const url=URL.createObjectURL(typeof content==='string'?new Blob([content],{type:'application/json'}):content);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
