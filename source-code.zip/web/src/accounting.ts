import type {Row} from './types';
export type AccountingLine={id:string;subaccounts:string;dimension:string;totals:string};
export type AccountingAccount={id:string;name:string;lines:AccountingLine[]};
export type AccountingIndicator={id:string;name:string;accounts:AccountingAccount[]};
export type AccountingScheme={format:1;indicators:AccountingIndicator[]};
export type DocCell={column:number;text:string;rowSpan:number;colSpan:number;omitted?:boolean};
export type AccountingReference={source:string;version:string;tables:DocCell[][][]};
export const blankLine=():AccountingLine=>({id:crypto.randomUUID(),subaccounts:'',dimension:'',totals:''});
export const blankAccount=():AccountingAccount=>({id:crypto.randomUUID(),name:'',lines:[blankLine()]});
export const blankIndicator=():AccountingIndicator=>({id:crypto.randomUUID(),name:'',accounts:[blankAccount()]});
export const emptyScheme=():AccountingScheme=>({format:1,indicators:[blankIndicator()]});
// Old attempts remain intact. Their flat rows are represented without discarding any input.
export function fromLegacy(rows:Row[]):AccountingScheme{
  if(!rows.length)return emptyScheme();
  const indicators:AccountingIndicator[]=[];
  for(const row of rows){const name=String(row.indicator??'');let indicator=indicators.at(-1);if(!indicator||indicator.name!==name){indicator={id:'indicator:'+row.id,name,accounts:[]};indicators.push(indicator);}const accountName=String(row.account??'');let account=indicator.accounts.at(-1);if(!account||account.name!==accountName){account={id:'account:'+row.id,name:accountName,lines:[]};indicator.accounts.push(account);}account.lines.push({id:row.id,subaccounts:String(row.subaccounts??''),dimension:String(row.dimension??''),totals:String(row.totals??'')});}
  return {format:1,indicators};
}
export function validScheme(s:any):s is AccountingScheme{
  const ids=new Set<string>();const id=(v:any)=>typeof v==='string'&&!!v&&!ids.has(v)&&(ids.add(v),true);
  return s?.format===1&&Array.isArray(s.indicators)&&s.indicators.every((i:any)=>id(i.id)&&typeof i.name==='string'&&Array.isArray(i.accounts)&&i.accounts.length>0&&i.accounts.every((a:any)=>id(a.id)&&typeof a.name==='string'&&Array.isArray(a.lines)&&a.lines.length>0&&a.lines.every((l:any)=>id(l.id)&&['subaccounts','dimension','totals'].every(k=>typeof l[k]==='string'))));
}
export function validReference(r:any):r is AccountingReference{
  return typeof r?.source==='string'&&typeof r.version==='string'&&Array.isArray(r.tables)&&r.tables.every((table:any)=>Array.isArray(table)&&table.length<=1000&&table.every((row:any,ri:number)=>Array.isArray(row)&&row.every((c:any)=>Number.isInteger(c.column)&&c.column>=0&&Number.isInteger(c.rowSpan)&&c.rowSpan>0&&c.rowSpan<=table.length-ri&&Number.isInteger(c.colSpan)&&c.colSpan>0&&c.colSpan<=5&&c.column+c.colSpan<=5&&typeof c.text==='string')));
}
export function move<T>(rows:T[],index:number,delta:number){const to=index+delta;if(to<0||to>=rows.length)return rows;const result=[...rows];[result[index],result[to]]=[result[to],result[index]];return result;}
