import {AccountingTable} from './AccountingEditor';
import {fromLegacy} from './accounting';
import type {DesignState,MetaObject,Row,Spec} from './types';
import {encode,index,options,ref,schema} from './model';
export function OwnWork({state:s,stage}:{state:DesignState;stage:string}){
  const idx=index(s),formulas=Object.fromEntries(s.formulas.map(f=>[f.id,f.name]));
  const show=(v:any):string=>v==null?'Не задано':Array.isArray(v)?v.length?v.map(show).join(', '):'Нет':ref(v)?idx[ref(v)!]?.label||formulas[ref(v)!]||'Удалённая ссылка':v===true?'Да':v===false?'Нет':String(v);
  const table=(rows:Row[],cols:Record<string,Spec>)=><div className="table-scroll"><table><thead><tr>{Object.values(cols).map(c=><th key={c.label}>{c.label}</th>)}</tr></thead><tbody>{rows.map(r=><tr key={r.id}>{Object.keys(cols).map(k=><td key={k}>{show(r[k])}</td>)}</tr>)}</tbody></table></div>;
  if(stage==='Схема учёта')return <AccountingTable scheme={s.accountingScheme||fromLegacy(s.accounting)}/>;
  if(stage==='Формулы и источники')return <>{s.formulas.map(f=><section key={f.id}><h4>{f.name}</h4><p>{f.formula||'Формула не задана'}</p>{s.variables.filter(v=>ref(v.kind)===f.id).map(v=><p key={v.id}>{v.name} · {v.source||'Источник не задан'} · {v.explanation}</p>)}</section>)}{!s.formulas.length&&<p>Виды расчёта не добавлены.</p>}</>;
  if(stage==='Таблица зависимостей')return table(s.dependencies,{kind:{label:'Вид расчёта',kind:'ref'},displacing:{label:'Вытесняющие',kind:'refs'},base:{label:'Базовые',kind:'refs'},leading:{label:'Ведущие',kind:'refs'},action_period:{label:'Использование периода действия',kind:'bool'}});
  const objects=s.objects.filter(o=>stage==='Регистры накопления'?o.kind==='Регистр накопления':stage==='Прочие объекты'?o.kind!=='Регистр накопления':true);
  return <>{objects.map(o=>{const [props,tables]=schema.definitions[o.kind];return <details key={o.id}><summary>{o.kind}: {o.name}</summary><dl>{Object.entries(props).map(([k,d])=><div className="property-review" key={k}><dt>{d.label}</dt><dd>{show(o.properties[k])}</dd></div>)}</dl>{Object.entries(tables).map(([key,cols])=>o.tables[key]?.length?<section key={key}><h4>{schema.tableNames[key]}</h4>{table(o.tables[key],cols)}</section>:null)}{o.choice_links.length>0&&<><h4>Связи параметров выбора</h4>{table(o.choice_links,{field:{label:'Поле',kind:'ref'},source:{label:'Источник',kind:'ref'},target:{label:'Назначение',kind:'ref'},parameter:{label:'Параметр',kind:'text'}})}</>}</details>;})}{!objects.length&&<p>Объекты не добавлены.</p>}</>;
}
