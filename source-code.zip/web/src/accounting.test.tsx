// @vitest-environment jsdom
import React,{useState} from 'react';
import {afterEach,it,expect} from 'vitest';
import {render,screen,fireEvent,cleanup} from '@testing-library/react';
import {AccountingEditor,AccountingTable,AccountingReferenceView} from './AccountingEditor';
import {emptyScheme,fromLegacy,validScheme,validReference,move} from './accounting';
import type {AccountingScheme} from './accounting';
afterEach(cleanup);
it('сохраняет таблицу при переходе между карточками и таблицей и добавляет уровни',()=>{
  let latest=emptyScheme();function Host(){const [value,set]=useState(latest);return <AccountingEditor value={value} legacy={[]} onChange={s=>{latest=s;set(s);}}/>;}
  render(<Host/>);
  fireEvent.change(screen.getByRole('textbox',{name:'Показатель 1'}),{target:{value:'Сумма'}});
  fireEvent.change(screen.getByRole('textbox',{name:'Счёт 1.1'}),{target:{value:'Товары'}});
  fireEvent.click(screen.getByRole('button',{name:'＋ Строка разрезов 1.1'}));
  fireEvent.change(screen.getByRole('textbox',{name:'Субконто 1.1.2'}),{target:{value:'Партия'}});
  fireEvent.change(screen.getByRole('combobox',{name:'Вид итогов 1.1.2'}),{target:{value:'Остатки'}});
  fireEvent.click(screen.getByRole('button',{name:'Карточки'}));
  expect((screen.getByRole('textbox',{name:'Субконто 1.1.2'}) as HTMLTextAreaElement).value).toBe('Партия');
  fireEvent.click(screen.getByRole('button',{name:'＋ Счёт для показателя 1'}));
  fireEvent.click(screen.getByRole('button',{name:'＋ Показатель'}));
  expect(latest.indicators).toHaveLength(2);expect(latest.indicators[0].accounts).toHaveLength(2);
  const id=latest.indicators[0].accounts[0].lines[1].id;
  fireEvent.click(screen.getByRole('button',{name:'Строка 1.1.2 выше'}));
  expect(latest.indicators[0].accounts[0].lines[0].id).toBe(id);
  fireEvent.click(screen.getByRole('button',{name:'Удалить показатель 2'}));
  expect(latest.indicators).toHaveLength(1);expect(validScheme(latest)).toBe(true);
});
it('отображает объединённые ячейки и сохраняет старые строки без потерь',()=>{
  const rows=[{id:'a',indicator:'Сумма',account:'Товары',subaccounts:'Номенклатура',dimension:'Организация',totals:'Остатки'},{id:'b',indicator:'Сумма',account:'Товары',subaccounts:'Партия',totals:'Оборот'}];
  const before=JSON.stringify(rows),scheme=fromLegacy(rows);expect(scheme.indicators[0].accounts[0].lines).toHaveLength(2);expect(JSON.stringify(rows)).toBe(before);
  const {container}=render(<AccountingTable scheme={scheme}/>);expect(container.querySelector('tbody th')?.getAttribute('rowspan')).toBe('2');expect(screen.getByText('Оборот')).toBeTruthy();
  const duplicate=structuredClone(scheme);duplicate.indicators[0].accounts[0].lines[0].id=duplicate.indicators[0].id;expect(validScheme(duplicate)).toBe(false);
  expect(move([1,2,3],1,-1)).toEqual([2,1,3]);
});
it('показывает Word как таблицу с сохранёнными объединениями',()=>{
  const reference={source:'1.docx',version:'sha',tables:[[[{column:0,text:'Показатель',rowSpan:2,colSpan:1},{column:1,text:'Разрезы',rowSpan:1,colSpan:3},{column:4,text:'Итоги',rowSpan:2,colSpan:1}],[{column:1,text:'Счёт',rowSpan:1,colSpan:1},{column:2,text:'Субконто',rowSpan:1,colSpan:1},{column:3,text:'Измерение',rowSpan:1,colSpan:1}]]]};
  expect(validReference(reference)).toBe(true);render(<AccountingReferenceView reference={reference}/>);expect(screen.getByRole('columnheader',{name:'Разрезы'}).getAttribute('colspan')).toBe('3');
  expect(validReference({...reference,tables:[[[{column:0,text:'x',rowSpan:99,colSpan:1}]]]})).toBe(false);
});
