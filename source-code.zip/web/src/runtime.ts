/** The update prompt can ask the active lesson to finish saving before reloading. */
export const lessonRuntime:{flush?:()=>Promise<boolean>}={};
