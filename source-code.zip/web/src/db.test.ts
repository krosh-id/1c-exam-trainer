import 'fake-indexeddb/auto';
import {beforeAll,describe,it,expect,vi} from 'vitest';
import {zipSync,strToU8} from 'fflate';
import {createRecord} from './logic';
import type {Ticket} from './types';
vi.stubGlobal('location',new URL('https://example.test/trainer/'));
const api=await import('./db');
const ticket={id:'test',section:'ОУ',version:'v',fragments:[],exercises:[],source:{sections:{},images:{}},images:{}} as unknown as Ticket;
describe('IndexedDB и резервные копии',()=>{
  it('восстанавливает запись и блокирует устаревшую ревизию',async()=>{const r=createRecord(ticket,'memory');const saved=await api.saveRecord(r);expect(saved.revision).toBe(1);expect((await api.readRecords())[0].id).toBe(r.id);await expect(api.saveRecord(r)).rejects.toThrow('другой вкладке');});
  it('повторный импорт идемпотентен; конфликт сохраняется отдельно',async()=>{const text=await api.exportProgress();expect(await api.importProgress(text)).toEqual({added:0,conflicts:0});const changed=JSON.parse(text);changed.records[0].answers={answer:'Другой ввод'};expect((await api.importProgress(JSON.stringify(changed))).conflicts).toBe(1);expect((await api.importProgress(JSON.stringify(changed))).conflicts).toBe(0);expect((await api.readRecords()).length).toBe(2);});
  it('не заменяет материалы повреждённым ZIP',async()=>{await expect(api.importPackage(new Uint8Array([1,2,3]))).rejects.toThrow();expect(await api.readMaterials()).toBeUndefined();const bytes=zipSync({'manifest.json':strToU8(JSON.stringify({format:1,files:{'materials.json':'bad'}})),'materials.json':strToU8('{}')});await expect(api.importPackage(bytes)).rejects.toThrow('Повреждён');});
  it('отвергает несовместимую резервную копию',async()=>{await expect(api.importProgress('{"format":2}')).rejects.toThrow();expect((await api.readRecords()).length).toBe(2);});
  it('поддерживает старые пакеты и не заменяет библиотеку при повреждённой ссылке',async()=>{
    const base={format:1,id:'library-test',tickets:[],seed:{objects:{ОУ:[],БУ:[],СПР:[]}},frequency:{},assets:{}};
    const pack=async(value:unknown)=>{const content=strToU8(JSON.stringify(value));const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(content).buffer))).map(n=>n.toString(16).padStart(2,'0')).join('');return zipSync({'manifest.json':strToU8(JSON.stringify({format:1,files:{'materials.json':digest}})),'materials.json':content});};
    expect((await api.parsePackage(await pack(base))).library).toBeUndefined();
    const note={id:'a',path:'a.md',title:'A',folder:'Теория',version:'1',content:'Текст',links:{},images:{},warnings:[]};
    await api.importPackage(await pack({...base,library:[note]}));
    await expect(api.importPackage(await pack({...base,library:[{...note,links:{b:{id:'missing'}}}]}))).rejects.toThrow('ссылка');
    expect((await api.readMaterials())?.library?.[0].content).toBe('Текст');
  });
});
