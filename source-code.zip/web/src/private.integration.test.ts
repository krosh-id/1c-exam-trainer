import 'fake-indexeddb/auto';
import {existsSync,readFileSync} from 'node:fs';
import {describe,it,expect,vi} from 'vitest';
import {normalize,gradeOrder} from './logic';
vi.stubGlobal('location',new URL('https://example.test/trainer/'));
const local=existsSync('private/materials.zip');
describe.skipIf(!local)('Личный пакет: все задания и сверка с Python',()=>{
  it('импортирует 54 задания и проверяет все упражнения',async()=>{const {parsePackage}=await import('./db');const m=await parsePackage(new Uint8Array(readFileSync('private/materials.zip')));expect(m.tickets).toHaveLength(54);let count=0;for(const t of m.tickets){for(const e of t.exercises){expect(gradeOrder(e,e.cards.map(c=>c.id)).every(Boolean)).toBe(true);if(e.cards.length>1){const reverse=e.cards.map(c=>c.id).reverse();expect(gradeOrder(e,reverse)).toHaveLength(e.cards.length);}count++;}}expect(count).toBe(335);expect(m.frequency.records).toBe(345);expect(m.tickets.find(t=>t.title==='БУ №2 Доп затраты на рекламу')).toMatchObject({additional:false,frequency:5});expect(m.tickets.find(t=>t.section==='СПР'&&t.number===7)?.exercises.length).toBeGreaterThan(0);expect(m.tickets.find(t=>t.section==='СПР'&&t.number===9)?.exercises.length).toBe(0);});
  it('нормализация всех фрагментов совпадает с Python',()=>{const data=JSON.parse(readFileSync('private/parity.json','utf-8'));for(const f of data)expect(normalize(f.source)).toBe(f.normalized);expect(data.length).toBeGreaterThan(200);});
  it.skipIf(!existsSync('private/browser-progress.json'))('восстанавливает реальную копию из браузера без дублей',async()=>{const api=await import('./db');const text=readFileSync('private/browser-progress.json','utf-8');const expected=JSON.parse(text).records;const first=await api.importProgress(text);expect(first.added).toBe(expected.length);expect((await api.readRecords()).length).toBe(expected.length);expect(await api.importProgress(text)).toEqual({added:0,conflicts:0});for(const r of await api.readRecords()){expect(r.snapshot.version).toBe(r.version);if(r.mode==='design')expect(r.state?.objects.length).toBeGreaterThan(0);}});
});
