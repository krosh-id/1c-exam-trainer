import {useEffect,useRef,useState} from 'react';
import {DndContext,KeyboardSensor,PointerSensor,TouchSensor,closestCenter,useSensor,useSensors,type DragEndEvent} from '@dnd-kit/core';
import {SortableContext,arrayMove,sortableKeyboardCoordinates,useSortable,verticalListSortingStrategy} from '@dnd-kit/sortable';
import {CSS} from '@dnd-kit/utilities';
import {attachAssets,saveRecord,download} from './db';
import {createRecord,gradeOrder,newDesign,normalize,shuffle} from './logic';
import type {Card,Materials,Mode,RecordItem,Ticket} from './types';
import {modeNames} from './types';
import {Code,Note,Rating,Badge} from './components';
import {DesignEditor} from './DesignEditor';
import {lessonRuntime} from './runtime';
// Keep unsaved input across in-app navigation, including an IndexedDB write failure.
const sessionDrafts=new Map<string,RecordItem>();
const draftKey=(r:RecordItem)=>r.ticketId+':'+r.version+':'+r.mode+':'+(r.mode==='order'?r.unit:'');

function SortCard({card,index,disabled,result,move,count}:{card:Card;index:number;disabled:boolean;result?:boolean;move:(to:number)=>void;count:number}){
  const {attributes,listeners,setNodeRef,transform,transition,isDragging}=useSortable({id:card.id,disabled});
  return <div ref={setNodeRef} style={{transform:CSS.Transform.toString(transform),transition,zIndex:isDragging?10:undefined}} className={'sort-card '+(isDragging?'dragging ':'')+(result===undefined?'':result?'correct':'incorrect')}><button className="drag-handle" {...attributes} {...listeners} disabled={disabled} aria-label={'Переместить строку '+(index+1)}>⠿</button><span className="line-number">{index+1}</span><div className="card-code"><Code text={card.display}/>{card.query_label&&<Badge>{card.query_label}</Badge>}</div><div className="move-buttons"><button disabled={disabled||index===0} aria-label={'Строка '+(index+1)+' выше'} onClick={()=>move(index-1)}>↑</button><button disabled={disabled||index===count-1} aria-label={'Строка '+(index+1)+' ниже'} onClick={()=>move(index+1)}>↓</button></div>{result!==undefined&&<span aria-label={result?'Совпадает':'Не совпадает'} className="result-icon">{result?'✓':'×'}</span>}</div>;
}
export function Training({t,m,records,onSaved,onBack}:{t:Ticket;m:Materials;records:RecordItem[];onSaved:(r:RecordItem)=>void;onBack:()=>void}){
  const previous=[...records,...sessionDrafts.values()].filter(r=>r.ticketId===t.id&&r.version===t.version).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt))[0];
  const [mode,setMode]=useState<Mode>(previous?.mode||'order'),[kind,setKind]=useState<string>(t.exercises.find(e=>e.id===previous?.unit)?.kind||'module'),[unit,setUnit]=useState(previous?.unit||''),[mobilePane,setMobilePane]=useState('work');
  const [record,setRecord]=useState<RecordItem|null>(null),[saveState,setSaveState]=useState(''),[error,setError]=useState(''),[nonce,setNonce]=useState(0);
  const latest=useRef<RecordItem|null>(null),saved=useRef<RecordItem|null>(null),pending=useRef(false),timer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined),alive=useRef(true);
  const saveJob=useRef<Promise<void>|null>(null);
  const ex=t.exercises.filter(e=>e.kind===kind).find(e=>e.id===unit)||t.exercises.filter(e=>e.kind===kind)[0];
  const contextKey=t.id+':'+t.version+':'+mode+':'+(mode==='order'?ex?.id:'');
  const sensors=useSensors(useSensor(PointerSensor,{activationConstraint:{distance:8}}),useSensor(TouchSensor,{activationConstraint:{delay:180,tolerance:6}}),useSensor(KeyboardSensor,{coordinateGetter:sortableKeyboardCoordinates}));
  useEffect(()=>()=>{clearTimeout(timer.current);void persist();alive.current=false;},[]);
  async function persist(){
    clearTimeout(timer.current);
    if(saveJob.current)return saveJob.current;
    if(!latest.current||JSON.stringify(latest.current)===JSON.stringify(saved.current))return;
    const run=async()=>{
      pending.current=true;setSaveState('Сохраняется…');
      try{
        while(latest.current&&JSON.stringify(latest.current)!==JSON.stringify(saved.current)){
          const value=structuredClone(latest.current);
          await attachAssets(value,m);
          const next=await saveRecord(value);
          saved.current=next;onSaved(next);
          if(latest.current?.id===value.id){
            latest.current={...latest.current,revision:next.revision,updatedAt:next.updatedAt,snapshot:next.snapshot};
            sessionDrafts.set(draftKey(latest.current),latest.current);
            if(alive.current)setRecord(latest.current);
          }
        }
        setSaveState('Сохранено на этом устройстве');setError('');
      }catch(e){setError((e as Error).message);setSaveState('Не сохранено');}
      finally{pending.current=false;}
    };
    const job=run();saveJob.current=job;await job;
    if(saveJob.current===job)saveJob.current=null;
  }
  // Context changes happen only after pending saves have finished, preventing cross-mode draft overwrites.
  useEffect(()=>{
    const old=records.filter(r=>r.ticketId===t.id&&r.version===t.version&&r.mode===mode&&(mode!=='order'||r.unit===ex?.id)).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt))[0];
    const resumed=nonce===0?(sessionDrafts.get(contextKey)||old):undefined;
    const r=resumed?structuredClone(resumed):createRecord(t,mode,mode==='order'?ex?.id:undefined);
    if(!resumed){if(mode==='order'&&ex)r.answers={order:shuffle(ex)};if(mode==='design')r.state=newDesign(m,t);}
    latest.current=r;saved.current=old&&old.id===r.id?structuredClone(old):null;setRecord(r);setError('');setSaveState(saved.current&&JSON.stringify(r)===JSON.stringify(saved.current)?'Сохранено на этом устройстве':resumed?'Есть несохранённый ввод':'Начните занятие');
    // records intentionally excluded: saves must not reset an active form.
  },[t.id,t.version,mode,ex?.id,nonce]);
  function update(r:RecordItem){const immediate=r.mode==='design'||r.rating!==latest.current?.rating||r.submitted!==latest.current?.submitted;r={...r,updatedAt:new Date().toISOString()};latest.current=r;sessionDrafts.set(contextKey,r);setRecord(r);setSaveState('Есть изменения…');clearTimeout(timer.current);if(immediate)void persist();else timer.current=setTimeout(persist,450);}
  async function switchContext(action:()=>void){await persist();if(pending.current){setError('Дождитесь сохранения перед переходом.');return;}if(latest.current&&JSON.stringify(latest.current)!==JSON.stringify(saved.current)){setError('Сначала сохраните ввод или создайте копию попытки.');return;}action();}
  useEffect(()=>{const save=()=>{if(document.visibilityState==='hidden')void persist();};document.addEventListener('visibilitychange',save);return()=>document.removeEventListener('visibilitychange',save);});
  useEffect(()=>{const flush=async()=>{await persist();return !pending.current&&JSON.stringify(latest.current)===JSON.stringify(saved.current);};lessonRuntime.flush=flush;return()=>{if(lessonRuntime.flush===flush)lessonRuntime.flush=undefined;};},[contextKey]);
  if(!record||record.mode!==mode||record.version!==t.version||(mode==='order'&&record.unit!==ex?.id))return <p>Загрузка занятия…</p>;
  const r=record,order:string[]=r.answers.order||[],fragments=t.fragments.filter(f=>f.code.trim());
  const move=(from:number,to:number)=>update({...r,answers:{order:arrayMove(order,from,to)}});
  const drag=(e:DragEndEvent)=>{if(e.over&&e.active.id!==e.over.id)move(order.indexOf(String(e.active.id)),order.indexOf(String(e.over.id)));};
  async function submit(){let next:RecordItem;if(mode==='order'&&ex){const results=gradeOrder(ex,order);next={...r,results,correct:results.every(Boolean),submitted:true,viewed:true};}else{const results=fragments.map(f=>normalize(r.answers[f.id]||'')===normalize(f.code));next={...r,results,correct:results.every(Boolean),submitted:true,viewed:true};}update(next);await persist();}
  return <><div className="training-heading"><button className="back" onClick={()=>void switchContext(onBack)}>← Все билеты</button><div className="actions"><span className="save-state" aria-live="polite">● {saveState}</span><button className="small" onClick={()=>void switchContext(()=>{setNonce(n=>n+1);})}>Новая попытка</button></div></div><h1>{t.title}</h1><p className="muted">{t.frequency===null?'Нет данных о частоте':t.frequency+' упоминаний за 2026 год'} · Источник {t.version.slice(0,10)}</p><div className="tabs">{Object.entries(modeNames).map(([key,label])=><button key={key} className={mode===key?'active':''} onClick={()=>void switchContext(()=>{setNonce(0);setMode(key as Mode);})}>{label}</button>)}</div>{error&&<div className="error" role="alert">{error}<div className="actions"><button onClick={()=>void persist()}>Повторить сохранение</button><button onClick={async()=>{const copy=structuredClone(r);await attachAssets(copy,m);download(JSON.stringify({format:1,kind:"one-c-progress",records:[copy],revisions:[]}),"unsaved-attempt.json");}}>Скачать текущую попытку</button><button onClick={()=>{const next={...r,id:crypto.randomUUID(),revision:0};saved.current=null;update(next);void persist();}}>Сохранить как новую попытку</button></div></div>}
  <div className="mobile-switch"><button className={mobilePane==='condition'?'active':''} onClick={()=>setMobilePane('condition')}>Условие</button><button className={mobilePane==='work'?'active':''} onClick={()=>setMobilePane('work')}>Решение</button></div>
  <div className={'lesson-layout pane-'+mobilePane}><aside className="condition panel"><div className="eyebrow">Задание · {t.section}</div><h2>Условие</h2>{t.condition?<Note text={t.condition} images={t.images} m={m} t={t}/>:<p className="notice">В заметке нет условия задания.</p>}</aside><section className="workspace panel">
    {mode==='design'?<DesignEditor key={r.id} record={r} onChange={update} m={m} t={t}/>:mode==='order'?<><div className="section-heading"><h2>Восстановите порядок</h2><Badge>{ex?.cards.length||0} блоков</Badge></div><p className="muted">Сравниваем с порядком из конспекта. Другой порядок может быть корректен в 1С.</p><div className="actions"><select aria-label="Модули или запросы" value={kind} onChange={e=>{const value=e.currentTarget.value;void switchContext(()=>{setKind(value);setUnit('');setNonce(0);});}}><option value="module">Модули</option><option value="query">Запросы</option></select><select aria-label="Фрагмент сборки" value={ex?.id||''} onChange={e=>{const value=e.currentTarget.value;void switchContext(()=>{setUnit(value);setNonce(0);});}}>{t.exercises.filter(e=>e.kind===kind).map(e=><option value={e.id} key={e.id}>{e.title}</option>)}</select></div>{!ex?<p className="notice">В заметке нет {kind==='query'?'отдельных запросов':'листинга модуля'} для сборки. Он станет доступен после обновления материалов.</p>:<><DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={drag}><SortableContext items={order} strategy={verticalListSortingStrategy}><div className="sort-list">{order.map((id,i)=>{const card=ex.cards.find(c=>c.id===id);return card?<SortCard key={id} card={card} index={i} count={order.length} disabled={r.submitted} result={r.results?.[i]} move={to=>move(i,to)}/>:null;})}</div></SortableContext></DndContext>{!r.submitted&&<button className="primary" onClick={()=>void submit()}>Проверить порядок</button>}</> }</>:<><h2>Восстановите решение</h2><p className="muted">Введите код по памяти. Проверяется совпадение с конспектом, без выполнения кода.</p>{!fragments.length?<p className="notice">В заметке пока нет листинга. После добавления кода загрузите обновлённый пакет.</p>:<>{fragments.map((f,i)=><section className="memory-fragment" key={f.id}><h3>{i+1}. {f.title}</h3><label className="field"><span>Ваш код</span><textarea className="code-input" spellCheck={false} value={r.answers[f.id]||''} readOnly={r.submitted} onChange={e=>update({...r,answers:{...r.answers,[f.id]:e.target.value}})} onKeyDown={e=>{if(e.key==='Tab'&&!r.submitted){e.preventDefault();const el=e.currentTarget,start=el.selectionStart,end=el.selectionEnd;update({...r,answers:{...r.answers,[f.id]:el.value.slice(0,start)+'\t'+el.value.slice(end)}});requestAnimationFrame(()=>el.selectionStart=el.selectionEnd=start+1);}}}/></label>{r.submitted&&<div className={r.results?.[i]?'match':'mismatch'}><b>{r.results?.[i]?'✓ Совпадает с конспектом':'≠ Отличается от конспекта'}</b><Code text={f.code}/></div>}</section>)}{!r.submitted&&<button className="primary" onClick={()=>void submit()}>Отправить и открыть эталоны</button>}</>}</>}
    {mode!=='design'&&r.submitted&&<section className="reference"><h3>{r.correct?'✓ Точное совпадение':'Есть отличия от конспекта'}</h3>{mode==='order'&&ex&&<details><summary>Эталонный порядок</summary>{ex.cards.map(c=><Code key={c.id} text={c.display}/>)}</details>}<Rating value={r.rating} onChange={v=>update({...r,rating:v})}/><label className="field"><span>Заметка об ошибках</span><textarea value={r.note||''} onChange={e=>update({...r,note:e.target.value})}/></label><p className="muted">Самооценка не является экзаменационным баллом.</p></section>}
  </section></div></>;
}
